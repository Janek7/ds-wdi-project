package de.uni_mannheim.informatik.web_data_integration;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
