package csvCompare;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class ComparatorClass {
	Doppel[] array = new Doppel[50000];
	private static final String COMMA_DELIMITER = ",";
	ArrayList<Steam> steamList = new ArrayList<Steam>();
	ArrayList<Wikidata> wikiList = new ArrayList<Wikidata>();

	public static void main(String[] args) {
		ComparatorClass c = new ComparatorClass();
		c.steamEinlesen();
		c.wikidataEinlesen();
		//c.vergleichenMatching();
		//c.vergleichenNonMatching();
		c.vergleichenMatchingCornerCases();
	}
	
	
	public void steamEinlesen() {
		BufferedReader br = null;
        try
        {
            //Reading the csv file
            br = new BufferedReader(new FileReader("src/csvCompare/steam.csv"));
            
            //Create List for holding Employee objects
            
            String line = "";
            //Read to skip the header
            br.readLine();
            //Reading from the second line
            while ((line = br.readLine()) != null) 
            {
                String[] steamDetails = line.split(COMMA_DELIMITER);
                
                if(steamDetails.length > 0 )
                {
                    //Save the employee details in Employee object
                	Steam st = new Steam(steamDetails[0], steamDetails[1], steamDetails[2], steamDetails[3], steamDetails[4], steamDetails[5]);
                    steamList.add(st);
                    
                }
            }
            
            //Lets print the Employee List
            /*for(Steam s : steamList)
            {
                System.out.println(s.getId() + " + " + s.getTitle());
            }*/
        }
        catch(Exception ee)
        {
            ee.printStackTrace();
        }
        finally
        {
            try
            {
                br.close();
            }
            catch(IOException ie)
            {
                System.out.println("Error occured while closing the BufferedReader");
                ie.printStackTrace();
            }
        }
		
	}
	
	
	public void wikidataEinlesen() {
		BufferedReader br = null;
        try
        {
            //Reading the csv file
            br = new BufferedReader(new FileReader("src/csvCompare/wikidata.csv"));
            
            //Create List for holding Employee objects
            
            String line = "";
            //Read to skip the header
            br.readLine();
            //Reading from the second line
            while ((line = br.readLine()) != null) 
            {
                String[] wikiDetails = line.split(COMMA_DELIMITER);
                
                if(wikiDetails.length > 0 )
                {
                    //Save the employee details in Employee object
                	//Wikidata wd = new Wikidata(wikiDetails[0], wikiDetails[1], wikiDetails[2], wikiDetails[3], wikiDetails[4], wikiDetails[5]);
                	Wikidata wd = new Wikidata(wikiDetails[0], wikiDetails[1], wikiDetails[2], "x", "x", "x");
                	wikiList.add(wd);
                    
                }
            }
            
            //Lets print the Employee List
            /*for(Wikidata w : wikiList)
            {
                System.out.println(w.getId() + " + " + w.getTitle());
            }*/
        }
        catch(Exception ee)
        {
            ee.printStackTrace();
        }
        finally
        {
            try
            {
                br.close();
            }
            catch(IOException ie)
            {
                System.out.println("Error occured while closing the BufferedReader");
                ie.printStackTrace();
            }
        }
        
        
	}
	
	public void vergleichenMatching() {
		int gleich = 0;
		for (int j=0; j<40200; j++) { //steamList.size()
			for (int i=0; i<wikiList.size(); i++) {
				// insg. 100 matches ben�tigt. f�r 50 nach windows gesucht und die restlichen auf mac und linux verteilt
	    		if (steamList.get(j).getTitle().equals(wikiList.get(i).getTitle()) && steamList.get(j).getPlatform().contains("linux") && wikiList.get(i).getPlatform().contains("Linux") ) {
	    			array[gleich]= new Doppel(steamList.get(j), wikiList.get(i));
	    			gleich++;
	    			break;
	    			
	    		}
	    	}
//			if (j==20000) {
//				System.out.println("test");
//			}
		}
		for (int i=0; i<30; i++) {
			System.out.println(array[i].steam.getId()+","+array[i].wikidata.getId()+",TRUE");
		}
		System.out.println("fertig");
    	
    }
	
	public void vergleichenNonMatching() {
		int gleich = 0;
		int zuletzt=2300;
		for (int j=12000; j<40200; j++) { //steamList.size()
			for (int i=zuletzt; i<wikiList.size(); i++) {
				// insg. 100 matches ben�tigt. f�r 50 nach windows gesucht und die restlichen auf mac und linux verteilt
	    		if (!steamList.get(j).getTitle().equals(wikiList.get(i).getTitle()) && !steamList.get(j).getPlatform().equals(wikiList.get(i).getPlatform()) ) {
	    			array[gleich]= new Doppel(steamList.get(j), wikiList.get(i) );
	    			gleich++;
	    			zuletzt=i+30;
	    			break;
	    		}
	    	}
			
		}
		for (int i=0; i<50; i++) {
			System.out.println(array[i].steam.getId()+","+array[i].wikidata.getId()+",FALSE");
		}
		System.out.println("fertig");
    	
    }
	
	public void vergleichenMatchingCornerCases() {
		int gleich = 0;
		//int zuletzt=0;
		for (int j=0; j<35000; j++) { //steamList.size()
			for (int i=0; i<wikiList.size(); i++) {
				// insg. 100 true matches ben�tigt. f�r 50 nach windows gesucht und die restlichen auf mac und linux verteilt
				// f�r falsche matches, geschaut ob wikidata titel den titel von steam contains und dann gleiche plattformen, unterschiedliche plattformen angegeben
	    		if (steamList.get(j).getTitle().contains(wikiList.get(i).getTitle()) && !wikiList.get(i).getTitle().equals(steamList.get(j).getTitle())  && steamList.get(j).getPlatform().contains("windows") && wikiList.get(i).getPlatform().contains("Windows") ) {
	    			array[gleich]= new Doppel(steamList.get(j), wikiList.get(i) );
	    			gleich++;
	    			//zuletzt=i+30;
	    			break;
	    		}
	    	}
			
		}
		for (int i=0; i<150; i++) {
			System.out.println(array[i].steam.getTitle()+" + " +array[i].wikidata.getTitle());
			System.out.println(array[i].steam.getId()+","+array[i].wikidata.getId()+",FALSE");
			System.out.println();
		}
		System.out.println("fertig");
    	
    }

}
