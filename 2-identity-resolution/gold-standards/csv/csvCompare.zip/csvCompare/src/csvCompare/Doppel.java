package csvCompare;

public class Doppel {
	Steam steam;
	Wikidata wikidata;
	
	public Doppel(Steam steam, Wikidata wikidata) {
		super();
		this.steam = steam;
		this.wikidata = wikidata;
	}
	public Steam getSteam() {
		return steam;
	}
	public void setSteam(Steam steam) {
		this.steam = steam;
	}
	public Wikidata getWikidata() {
		return wikidata;
	}
	public void setWikidata(Wikidata wikidata) {
		this.wikidata = wikidata;
	}
	
	

	

}
