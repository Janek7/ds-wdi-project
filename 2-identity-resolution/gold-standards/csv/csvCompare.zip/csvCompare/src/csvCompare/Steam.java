package csvCompare;

public class Steam {
	private String id;
	private String title;
	private String platform;
	private String publisher;
	private String publishingdate;
	private String Developer;
	public Steam(String id, String title, String platform, String publisher, String publishingdate, String developer) {
		super();
		this.id = id;
		this.title = title;
		this.platform = platform;
		this.publisher = publisher;
		this.publishingdate = publishingdate;
		Developer = developer;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPublishingdate() {
		return publishingdate;
	}
	public void setPublishingdate(String publishingdate) {
		this.publishingdate = publishingdate;
	}
	public String getDeveloper() {
		return Developer;
	}
	public void setDeveloper(String developer) {
		Developer = developer;
	}
	
	
}
